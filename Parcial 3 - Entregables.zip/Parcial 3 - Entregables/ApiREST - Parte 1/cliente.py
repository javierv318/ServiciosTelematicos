import requests

# URL base de la API
base_url = 'http://localhost:5000'

# Obtener todos los libros
def get_books():
    url = f'{base_url}/books'
    response = requests.get(url)
    return response.json()

# Obtener un libro por su ID
def get_book(book_id):
    url = f'{base_url}/books/{book_id}'
    response = requests.get(url)
    return response.json()

# Agregar un nuevo libro
def create_book(title, description, author):
    url = f'{base_url}/books'
    data = {
        'title': title,
        'description': description,
        'author': author
    }
    response = requests.post(url, json=data)
    return response.json()

# Actualizar un libro existente
def update_book(book_id, title, description, author):
    url = f'{base_url}/books/{book_id}'
    data = {
        'title': title,
        'description': description,
        'author': author
    }
    response = requests.put(url, json=data)
    return response.json()

# Eliminar un libro
def delete_book(book_id):
    url = f'{base_url}/books/{book_id}'
    response = requests.delete(url)
    return response.json()

# Ejemplos de uso
if __name__ == '__main__':
    # Obtener todos los libros
    books = get_books()
    print('==================== Lista de libros: ====================')
    if books is None:
        print("No hay libros para encontrar")
    else:
        print(books)

    print('')
    print('')

    # Obtener un libro por su ID
    book_id = 4
    book = get_book(book_id)
    print(f'==================== Información del libro con ID {book_id}: ====================')
    if book is None:
        print("No se encontro el libro")
    else:
        print(book)

    print('')
    print('')

    # Agregar un nuevo libro
    new_book = create_book('Prueba sustentacion', 'Sustentacion', 'JAVP')
    print('==================== Nuevo libro agregado: ====================')
    print(new_book)

    print('')
    print('')

    # Actualizar un libro existente
    book_id = 5
    updated_book = update_book(book_id, 'Libro actualizado PRUEBA', 'Descripción actualizada PRUEBA', 'Autor actualizado PRUEBA')
    print(f'==================== Libro con ID {book_id} actualizado: ====================')
    print(updated_book)

    print('')
    print('')

    # Eliminar un libro
    book_id = 6
    result = delete_book(book_id)
    print(f'==================== Libro con ID {book_id} eliminado: ====================')
    if book is None:
        print("No se encontro el libro")
        print(result)
    else:
        print(result)
