La carpeta "venv" es una carpeta de ambiente propio de la maquina personal

Para poder correr esta APIRest con el cliente, realizar los siguiente pasos:

1. Crear un entorno personal en la maquina (borrar la venv anterior):
python -m venv venv

2. Dirigirnos al entorno y activar el script:
.\venv\Scripts\activate

Instalar los paquetes necesarios para correr la app:
pip install flask
pip install flask-mysqldb
pip install flask-cors
pip install requests

TENER EN CUENTA QUE EN LA MAQUINA DEBE ESTAR CREADA LA BASE DE DATOS EN MYSQL

Si no la tienen usar estos comandos como ejemplo:

CREATE DATABASE apiREST;
use apiREST;

CREATE TABLE books (
    id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title varchar(255),
    description varchar(255),
    author varchar(255)
);


INSERT INTO books VALUES(null, "Señores de las sombras", "Interesante", "Daniel Stullin"),
    (null, "El señor de los anillos", "Brillante", "J. R. R. Tolkien");

SELECT * FROM books;

TRUNCATE TABLE books;

ALTER TABLE books AUTO_INCREMENT = 1;