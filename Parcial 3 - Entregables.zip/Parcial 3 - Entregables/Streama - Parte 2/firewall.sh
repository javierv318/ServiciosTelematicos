#!/bin/bash

echo "configurando el selinux para desactivarlo"
sudo cat <<TEST> /etc/selinux/config
# This file controls the state of SELinux on the system.
# SELINUX= can take one of these three values:
#     enforcing - SELinux security policy is enforced.
#     permissive - SELinux prints warnings instead of enforcing.
#     disabled - No SELinux policy is loaded.
SELINUX=disabled
# SELINUXTYPE= can take one of three values:
#     targeted - Targeted processes are protected,
#     minimum - Modification of targeted policy. Only selected processes are protected.
#     mls - Multi Level Security protection.
SELINUXTYPE=targeted
TEST

sudo yum install vim -y
sudo yum install bind-utils bind-libs bind-* -

sudo service NetworkManager stop
sudo chkconfig NetworkManager off

sudo service firewalld start
sudo service firewalld enable

sudo firewall-cmd --zone=public --remove-interface=eth0 --permanent
sudo firewall-cmd --zone=public --remove-interface=eth2 --permanent
sudo firewall-cmd --zone=public --remove-interface=eth1 --permanent
sudo firewall-cmd --zone=public --add-interface=eth1 --permanent
sudo firewall-cmd --zone=public --add-service=ftp --permanent
sudo firewall-cmd --zone=public --add-service=dns --permanent
sudo firewall-cmd --zone=public --add-masquerade --permanent

sudo firewall-cmd --permanent --zone=public --add-forward-port=port=80:proto=tcp:toport=8080:toaddr=192.168.50.4
sudo firewall-cmd --zone=public --add-service=http --permanent
sudo firewall-cmd --zone=internal --add-masquerade --permanent
sudo firewall-cmd --reload
sudo firewall-cmd --list-all-zones

